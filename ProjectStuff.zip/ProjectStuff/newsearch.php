<?php
// TEAM Stooges- Moe Howard, Larry Fine, Jerome Howard, Shemp Howard
    $con = mysqli_connect("localhost", "root", "root") or die("Error connecting to database: ".mysqli_error());
    
     
    mysqli_select_db($con, "project") or die(mysqli_error());
   
?>
 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Search results</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="style.css"/>
	<!--TEAM Stooges- Moe Howard, Larry Fine, Jerome Howard, Shemp Howard -->
</head>
<body>
<a href="index.html">Return to Switchboard</a></br>

<table border=1 cellpadding=2 cellspacing=1>

<tr>
<th>ID</th>
<th>First Name </th>
<th>Last Name </th>
<th>Address </th>
<th>City </th>
<th>State </th>
<th>Zip Code </th>
<th>email</th>
</tr>
<?php
    $query = $_POST['query']; 
    // gets value sent over search form
         
        $query = htmlspecialchars($query); 
        // changes characters used in html to their equivalents, for example: < to &gt;
         
        $query = mysqli_real_escape_string($con, $query);
        // makes sure nobody uses SQL injection */
         
        $sql =("SELECT * FROM customer
            WHERE (`CustID` LIKE '%".$query."%') OR (`LastName` LIKE '%".$query."%')");

		//check to see that that a search term was entered
		if (!$query)
 {
	 echo "<h2>You did not enter anything to search for</h2>.</br>";
	 echo "<a href=newsearcher.html>"."Please enter a search term"."</a>";
	 exit;
 }
			// execute the SELECT Query
$records = mysqli_query($con, $sql);

//Fetch the records

while ($row = mysqli_fetch_array($records))

{
	echo "<tr>";
	echo "<td>".$row['CustID']."</td>";
	echo "<td>".$row['FirstName']."</td>";
	echo "<td>".$row['LastName']."</td>";
	echo "<td>".$row['Address1']."</td>";
	echo "<td>".$row['City']."</td>";
	echo "<td>".$row['State']."</td>";
	echo "<td>".$row['zip']."</td>";
	echo "<td>".$row['email']."</td>";
}
    if(mysqli_query($con, $sql))
		echo "<p>" . mysqli_affected_rows($con) . " row(s) found"."</p>";
	
	else
		echo "No records found.";
    
	?>
</body>
</html>