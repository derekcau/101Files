<?php
// TEAM Stooges- Moe Howard, Larry Fine, Jerome Howard, Shemp Howard
//Create connection with MySQL

//Make connection variable
$con = mysqli_connect('127.0.0.1', 'root','root');
//check the connection
if (!$con)
{
	echo 'Not connected';
}
 //set variables from the POST array
$first= $_POST['firstname'];
$last= $_POST['lastname'];
$address= $_POST['address'];
$city = $_POST['city'];
$state = $_POST['state'];
$zip = $_POST['zip'];
$email = $_POST['email'];
$id = $_POST['id'];


if (!mysqli_select_db($con, 'project'))
{
	echo 'Database Not Selected';
}

/*Update Query demonstrating using $_POST array elements
$sql = "UPDATE customer  SET FirstName='$_POST[firstname]', LastName='$_POST[lastname]',Address1='$_POST[address]',City='$_POST[city]',State='$_POST[state]',zip='$_POST[zip]',email='$_POST[email]' WHERE CustID=$_POST[id]"; */

//Update Query demonstrating variables
$sql = "UPDATE customer  SET FirstName='$first',LastName='$last',Address1='$address',City='$city',State='$state',zip='$zip',email='$email' WHERE CustID='$id'"; 


// execute the Update Query
if(mysqli_query($con, $sql))
	echo "<p>" . mysqli_affected_rows($con) . " row(s) updated"."</p>"."</br>".
	header("refresh:3 url= Updater.php");
else
	echo "Not updated.";

?>