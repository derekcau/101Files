<html>
<head>
<title>Update Records in MySQL Using PHP
</title>
<!--TEAM Stooges- Moe Howard, Larry Fine, Jerome Howard, Shemp Howard -->
</head>
<body>

<!-- create header -->


<?php

//Create connection with MySQL

//Make connection variable
$con = mysqli_connect('127.0.0.1', 'root','root');
//check the connection
if (!$con)
{
	echo 'Not connected';
}

if (!mysqli_select_db($con, 'project'))
{
	echo 'Database Not Selected';
}
//Select Query
$sql = "SELECT * FROM customer";

// execute the SELECT Query
$records = mysqli_query($con, $sql);

?>
<a href="index.html">Return to Switchboard</a>

<table border=1 cellpadding=2 cellspacing=1>

<tr>
<th>First Name </th>
<th>Last Name </th>
<th>Address </th>
<th>City </th>
<th>State </th>
<th>Zip Code </th>
<th>email</th>
</tr>

<?php

//Fetch the records, make each line a form, and submit changes to an action page

while ($row = mysqli_fetch_array($records))
{
	echo "<tr><form action=update2.php method=post>";
	echo "<td><input type=text name=firstname value='".$row['FirstName']."'></td>";
	echo "<td><input type=text name=lastname value='".$row['LastName']."'></td>";
	echo "<td><input type=text name=address value='".$row['Address1']."'></td>";
	echo "<td><input type=text name=city value='".$row['City']."'></td>";
	echo "<td><input type=text name=state value='".$row['State']."'></td>";
	echo "<td><input type=text name=zip value='".$row['zip']."'></td>";
	echo "<td><input type=text name=email value='".$row['email']."'></td>";
	echo "<input type=hidden name=id value= '".$row['CustID']."'></td>";
	echo "<td><input type=submit>";
	echo "</form></tr>";
}
 
?>
</table>

</body>
</html>