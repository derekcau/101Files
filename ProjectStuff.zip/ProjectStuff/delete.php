<?php
// TEAM Stooges- Moe Howard, Larry Fine, Jerome Howard, Shemp Howard
	// connect to database
$con = mysqli_connect('127.0.0.1', 'root','root');
	//check the connection
if (!$con)
{
	echo 'Not connected';
}
	// select the database
if (!mysqli_select_db($con, 'project'))
{
	echo 'Database Not Selected';
}
//DELETE Query
$sql = "DELETE FROM customer WHERE CustID='$_GET[id]'";

// execute the Query
if(mysqli_query($con, $sql))
{	
	echo  mysqli_affected_rows($con)." record(s) deleted".
	header("refresh:3; url=deleter.php");
}	
else
{
	echo "Not deleted";
}
?>