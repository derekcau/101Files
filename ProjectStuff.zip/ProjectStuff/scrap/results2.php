<html>
<head>
<title>Search MySQL Using PHP
</title>
</head>
<body>
  <a href="index.html">Return to Switchboard</a>

<!-- create header -->

<table border=1 cellpadding=8 cellspacing=1>
<tr><td colspan="8" align= center><h1>Customer List</h1></td></tr>
<tr>
<th> ID</th>
<th>First Name </th>
<th>Last Name </th>
<th>Address </th>
<th>City </th>
<th>State </th>
<th>Zip Code </th>
<th>email</th>
</tr>

<?php

//Create connection with MySQL

//Make connection variable
$con = mysqli_connect('127.0.0.1', 'root','root');
//check the connection
if (!$con)
{
	echo 'Not connected';
}

if (!mysqli_select_db($con, 'project'))
{
	echo 'Database Not Selected';
}
    // create short variable names
    $searchtype=$_POST['searchtype'];
    $searchterm="%{$_POST['searchterm']}%";
	
	    if (!$searchtype || !$searchterm) {
       echo '<p>You have not entered search details.<br/>
       Please go back and try again.</p>';
       exit;
    }
    // whitelist the searchtype
    switch ($searchtype) {
      case 'id':
      case 'first':
      case 'last':
	  case 'email':
	}
     /*   ERROR TRAPPING FAIL break;
     default: 
        echo '<p>That is not a valid search type. <br/>
        Please go back and try again.</p>';
        exit; */
//Select Query- ? meant to limit input of special characters throws a SQL error
$sql = "SELECT * FROM customer WHERE $searchtype =?";

/*Alternative SQL Query of any field returns all records instead of selected
$sql = "SELECT * FROM customer WHERE $searchtype =CustID";

// execute the SELECT Query
$records = mysqli_query($con, $sql);
if($records === FALSE) { 
    die(mysqli_error($con)); // TODO: better error handling
}

//Fetch the records

while ($row=mysqli_fetch_array($records))

{
	echo "<tr>";
	echo "<td>".$row['CustID']."</td>";
	echo "<td>".$row['FirstName']."</td>";
	echo "<td>".$row['LastName']."</td>";
	echo "<td>".$row['Address1']."</td>";
	echo "<td>".$row['City']."</td>";
	echo "<td>".$row['State']."</td>";
	echo "<td>".$row['zip']."</td>";
	echo "<td>".$row['email']."</td>";
}
 
?>
</table>

</body>
</html>