<!DOCTYPE html>
<html>
<head>
  <title>Customer Search Results</title>
</head>
<body>
  <h1>Customer Search Results</h1>
  <?php
    // create short variable names
    $searchtype=$_POST['searchtype'];
    $searchterm="%{$_POST['searchterm']}%";

    if (!$searchtype || !$searchterm) {
       echo '<p>You have not entered search details.<br/>
       Please go back and try again.</p>';
       exit;
    }

    // whitelist the searchtype
    switch ($searchtype) {
      case 'id':
      case 'first':
      case 'last':
	  //case 'address':
	  //case 'zip':
	  case 'email':
	  
        break;
      default: 
        echo '<p>That is not a valid search type. <br/>
        Please go back and try again.</p>';
        exit; 
    }

    
	$con = mysqli_connect('127.0.0.1', 'root','root');
//check the connection
if (!$con)
{
	echo 'Not connected';
}

if (!mysqli_select_db($con, 'project'))
{
	echo 'Database Not Selected';
}
    $query = "SELECT CustID, FirstName, LastName, email FROM customers WHERE $searchterm = ?";

    // echo "<p>Number of records found: ".$num_results = mysqli_num_rows($result)."</p>";
	$records = mysqli_query($con, $query);
    while($row = mysqli_fetch_array($records)) {
      echo "<p><strong>LastName: ".$last."</strong>";
      echo "<br />FirstName: ".$first;
      echo "<br />email: ".$email;
      //echo "<br />Price: \$".number_format($price,2)."</p>";
    }

    //$db->close();
  ?>
</body>
</html>
