<html>
<head>
<title>Product listing
</title>
<!--TEAM Stooges- Moe Howard, Larry Fine, Jerome Howard, Shemp Howard -->
</head>
<body>
  <a href="index.html">Return to Switchboard</a>

<!-- create header -->

<table border=1 cellpadding=8 cellspacing=1>
<tr><td colspan="8" align= center><h1>Product List</h1></td></tr>
<tr>
<th>PID</th>
<th>Product </th>
<th>Price </th>
<th>Description </th>

</tr>

<?php

//Create connection with MySQL

//Make connection variable
$con = mysqli_connect('127.0.0.1', 'root','root');
//check the connection
if (!$con)
{
	echo 'Not connected';
}

if (!mysqli_select_db($con, 'project'))
{
	echo 'Database Not Selected';
}

//Select Query
$sql = "SELECT * FROM products";

// execute the SELECT Query
$records = mysqli_query($con, $sql);

//Fetch the records

while ($row = mysqli_fetch_array($records))

{
	echo "<tr>";
	echo "<td>".$row['pid']."</td>";
	echo "<td>".$row['product']."</td>";
	echo "<td>"."$".$row['price']."</td>";
	echo "<td>".$row['description']."</td>";
}
 
?>
</table>

</body>
</html>