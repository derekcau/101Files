<html>
<head>
<title>Delete Records- CAUTION!
</title>
<!--TEAM Stooges- Moe Howard, Larry Fine, Jerome Howard, Shemp Howard -->
</head>
<body>

<a href="index.html">Return to Switchboard</a>
  
<!-- Make table and header -->
<table border=1 cellpadding=2 cellspacing=1>
<tr>
	<th>First Name </th>
	<th>Last Name </th>
	<th>Address </th>
	<th>City </th>
	<th>State </th>
	<th>Zip Code </th>
	<th>email</th>
	<th>Delete</th>
</tr>

<?php
	// connect to database
$con = mysqli_connect('127.0.0.1', 'root','root');
	//check the connection
if (!$con)
{
	echo 'Not connected';
}
	// select the database
if (!mysqli_select_db($con, 'project'))
{
	echo 'Database Not Selected';
}	
	//Select Query
$sql = "SELECT * FROM customer";

// execute the SELECT Query
$records = mysqli_query($con, $sql);
	//Display the records 
while ($row = mysqli_fetch_array($records))
{
	echo "<tr>";
	echo "<td>".$row['FirstName']."</td>";
	echo "<td>".$row['LastName']."</td>";
	echo "<td>".$row['Address1']."</td>";
	echo "<td>".$row['City']."</td>";
	echo "<td>".$row['State']."</td>";
	echo "<td>".$row['zip']."</td>";
	echo "<td>".$row['email']."</td>";
	echo "<td><a href=delete.php?id=".$row['CustID'].">Delete</a></td>";
	echo "</tr>";	
}
?>
</table>
</body>
</html>