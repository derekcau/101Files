-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 14, 2018 at 11:26 PM
-- Server version: 5.6.35
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--
CREATE DATABASE IF NOT EXISTS `project` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `project`;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `CustID` int(11) NOT NULL,
  `FirstName` varchar(20) NOT NULL,
  `LastName` varchar(20) NOT NULL,
  `Address1` varchar(25) NOT NULL,
  `City` varchar(25) NOT NULL,
  `State` varchar(25) DEFAULT NULL,
  `zip` varchar(5) NOT NULL,
  `email` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CustID`, `FirstName`, `LastName`, `Address1`, `City`, `State`, `zip`, `email`) VALUES
(3, 'Douglass', 'Tackle', '6 Artisan Park', 'Buffalo', 'NY', '14275', 'dtackleg@wsj.com'),
(4, 'Garvy', 'Orta', '653 Porter Road', 'Buffalo', 'NY ', '14267', 'gortal@nature.com'),
(5, 'Berni', 'Constantinou', '57552 Evergreen Park', 'Buffalo', 'NY', '14263', 'bconstantinoun@tumblr.com'),
(6, 'Sinclair', 'Meaden', '578 Straubel Crossing', 'Buffalo', 'NY', '14214', 'smeadenq@latimes.com'),
(7, 'Scot', 'Beynkn', '907 David Parkway', 'Buffalo', 'NY', '14265', 'sbeynkn17@about.com'),
(8, 'Ara', 'Bellow', '2092 Stang Avenue', 'Buffalo', 'NY', '14211', 'abellow1b@biglobe.ne.jp'),
(9, 'Ebba', 'Warhurst', '6232 Merry Alley', 'Buffalo', 'NY', '14225', 'ewarhurst1c@dyndns.org'),
(10, 'Vernon', 'Cristofolini', '30 Lyons Lane', 'Buffalo', 'NY', '14269', 'vcristofolini1e@gravatar.'),
(11, 'Frederik', 'Le Leu', '13709 Badeau Crossing', 'Buffalo', 'NY', '14225', 'fleleu23@indiegogo.com'),
(12, 'Madelyn', 'OConnor', '1 Twin Pines Plaza', 'Buffalo', 'NY', '14205', 'modrought2t@telegraph.co.'),
(13, 'Lloyd', 'Smallacombe', '45 Lillian Plaza', 'Buffalo', 'NY', '14233', 'lsmallacombe37@wikia.com'),
(14, 'Ermanno', 'Stigers', '3 High Crossing Crossing', 'Buffalo', 'NY', '14210', 'estigers3t@instagram.com'),
(15, 'Ileana', 'Andrivot', '56730 Jana Alley', 'Buffalo', 'NY', '14210', 'iandrivot3v@ucoz.ru'),
(16, 'Patin', 'Sumbler', '4 Lakewood Pass', 'Buffalo', 'NY', '14263', 'psumbler4p@com.com'),
(17, 'Kattie', 'Jedrasik', '5040 Longview Avenue', 'Buffalo', 'NY', '14205', 'kjedrasik4v@wikimedia.org'),
(18, 'Cleon', 'Geeves', '67 Mesta Crossing', 'Buffalo', 'NY', '14225', 'cgeeves50@vinaora.com'),
(19, 'Averil', 'Offell', '706 Northridge Parkway', 'Buffalo', 'NY', '14225', 'aoffell56@seattletimes.co'),
(20, 'Elsa', 'Rylands', '50592 Red Cloud Way', 'Buffalo', 'NY', '14233', 'erylands5e@stanford.edu'),
(21, 'Lek', 'Anten', '936 Cambridge Terrace', 'Buffalo', 'NY', '14220', 'lanten5p@xrea.com'),
(22, 'Gwendolin', 'De Freitas', '2 Pawling Plaza', 'Buffalo', 'NY', '14276', 'gdefreitas5z@wikia.com'),
(23, 'Melvin', 'Otson', '40 Del Mar Avenue', 'Buffalo', 'NY', '14233', 'motson67@slate.com'),
(24, 'Crystie', 'Depper', '71202 Holmberg Lane', 'Buffalo', 'NY', '14276', 'cdepper6u@twitpic.com'),
(25, 'Guenevere', 'Farlambe', '8908 Comanche Junction', 'Buffalo', 'NY', '14263', 'gfarlambe6w@marriott.com'),
(26, 'Goraud', 'Wonfar', '59952 Armistice Junction', 'Buffalo', 'NY', '14210', 'gwonfar7g@ycombinator.com'),
(27, 'Arron', 'Cockshot', '07098 Randy Place', 'Buffalo', 'NY', '14233', 'acockshot8w@usatoday.com'),
(28, 'Bobbie', 'Carruthers', '31861 Forest Dale Circle', 'Buffalo', 'NY', '14215', 'bcarruthers8y@japanpost.j'),
(29, 'Hestia', 'Biscomb', '4220 1st Plaza', 'Buffalo', 'NY', '14269', 'hbiscomb97@wikipedia.org'),
(30, 'Muffin', 'Thraves', '4324 Carberry Way', 'Buffalo', 'NY', '14233', 'mthraves99@intel.com'),
(31, 'Mufi', 'Viner', '9 Corben Point', 'Buffalo', 'NY', '14233', 'mviner9g@bloglines.com'),
(32, 'Opalina', 'Uman', '1 Sunnyside Park', 'Buffalo', 'NY', '14263', 'ouman9h@biblegateway.com'),
(33, 'Winna', 'Larmuth', '87613 Lyons Point', 'Buffalo', 'NY', '14276', 'wlarmuthag@vk.com'),
(34, 'Baudoin', 'Astman', '14369 Brickson Park Alley', 'Buffalo', 'NY', '14210', 'bastmanaw@live.com'),
(35, 'Dani', 'Chellam', '2173 Helena Crossing', 'Buffalo', 'NY', '14220', 'dchellamb2@mapquest.com'),
(36, 'Jonathan', 'Aleshintsev', '726 Beilfuss Crossing', 'Buffalo', 'NY', '14225', 'jaleshintsevbe@aol.com'),
(37, 'Hersh', 'Skurm', '79159 Blue Bill Park Way', 'Buffalo', 'NY', '14210', 'hskurmbt@google.co.jp'),
(38, 'Anallise', 'McDoual', '12534 Hoepker Lane', 'Buffalo', 'NY', '14225', 'amcdoualbu@census.gov'),
(39, 'Johannah', 'McGlue', '865 Jana Junction', 'Buffalo', 'NY', '14225', 'jmcgluec5@e-recht24.de'),
(40, 'Daren', 'Bossons', '18 Loeprich Way', 'Buffalo', 'NY', '14220', 'dbossonscb@cisco.com'),
(41, 'Harwell', 'Ghirardi', '04 Commercial Trail', 'Buffalo', 'NY', '14263', 'hghirardicc@qq.com'),
(42, 'Beatriz', 'Duckham', '637 Graedel Terrace', 'Buffalo', 'NY', '14210', 'bduckhamcf@harvard.edu'),
(43, 'Haroun', 'Gotfrey', '0 Basil Park', 'Buffalo', 'NY', '14269', 'hgotfreyd1@diigo.com'),
(44, 'Lyn', 'Rosborough', '5355 Gateway Way', 'Buffalo', 'NY', '14205', 'lrosboroughdf@csmonitor.c'),
(45, 'Zebulon', 'Mattersey', '86 Riverside Road', 'Buffalo', 'NY', '14210', 'zmatterseydk@github.com'),
(46, 'Alair', 'Casotti', '3 Summerview Lane', 'Buffalo', 'NY', '14210', 'acasottids@pcworld.com'),
(47, 'Jacquelin', 'Blowin', '230 Debs Plaza', 'Buffalo', 'NY', '14276', 'jblowindx@icq.com'),
(48, 'Biddie', 'Vel', '5 Moose Parkway', 'Buffalo', 'NY', '14205', 'bvele0@123-reg.co.uk'),
(49, 'Camella', 'Jewitt', '89 Northland Junction', 'Buffalo', 'NY', '14276', 'cjewittep@usgs.gov'),
(50, 'Spence', 'Castellet', '6182 Hovde Parkway', 'Buffalo', 'NY', '14205', 'scastelletf9@redcross.org'),
(51, 'Magda', 'Fawckner', '1 Lotheville Alley', 'Buffalo', 'NY', '14225', 'mfawcknerfh@noaa.gov'),
(52, 'Blinni', 'Gever', '322 Scoville Road', 'Buffalo', 'NY', '14215', 'bgeverfj@odnoklassniki.ru'),
(53, 'Libby', 'MacEveley', '4 Blue Bill Park Alley', 'Buffalo', 'NY', '14205', 'lmaceveleyfs@barnesandnob'),
(54, 'Ricard', 'Booi', '51 Buena Vista Parkway', 'Buffalo', 'NY', '14276', 'rbooifz@google.com'),
(55, 'Chrissie', 'Calltone', '49 Crescent Oaks Drive', 'Buffalo', 'NY', '14215', 'ccalltonegw@opensource.or'),
(56, 'Marc', 'Edess', '5170 School Pass', 'Buffalo', 'NY', '14269', 'medessh5@ycombinator.com'),
(57, 'Aimee', 'Filippone', '90649 Thierer Drive', 'Buffalo', 'NY', '14205', 'afilipponeh7@ox.ac.uk'),
(58, 'Lari', 'Davidovici', '025 Walton Circle', 'Buffalo', 'NY', '14210', 'ldavidovicihf@bing.com'),
(59, 'Purcell', 'Luscombe', '3122 Thierer Terrace', 'Buffalo', 'NY', '14205', 'pluscombehr@yellowbook.co'),
(60, 'Hilly', 'Leban', '65 Ludington Plaza', 'Buffalo', 'NY', '14263', 'hlebanhs@twitpic.com'),
(61, 'Mureil', 'Brownsall', '2193 Debra Trail', 'Buffalo', 'NY', '14220', 'mbrownsalli6@devhub.com'),
(62, 'Luke', 'Yanne', '6 Randy Terrace', 'Buffalo', 'NY', '14269', 'lyannej1@merriam-webster.'),
(63, 'Angeli', 'Selwin', '03553 Nelson Terrace', 'Buffalo', 'NY', '14215', 'aselwinjc@e-recht24.de'),
(64, 'Boycie', 'Mayho', '5097 Corry Park', 'Buffalo', 'NY', '14205', 'bmayhok6@phoca.cz'),
(65, 'Wilbur', 'Headan', '9 Monica Junction', 'Buffalo', 'NY', '14220', 'wheadankc@jimdo.com'),
(66, 'Eleanor', 'Garrigan', '6773 Banding Alley', 'Buffalo', 'NY', '14225', 'egarrigankd@adobe.com'),
(67, 'Chrystel', 'Lovick', '37364 Clove Parkway', 'Buffalo', 'NY', '14210', 'clovickkf@feedburner.com'),
(68, 'Tania', 'Book', '1 2nd Street', 'Buffalo', 'NY', '14276', 'tbookki@trellian.com'),
(69, 'Kaja', 'Baggelley', '5 Kim Point', 'Buffalo', 'NY', '14215', 'kbaggelleykv@cbc.ca'),
(70, 'Doralynn', 'Dimmer', '00149 Dawn Way', 'Buffalo', 'NY', '14276', 'ddimmerl4@creativecommons'),
(71, 'Roland', 'Wasling', '5921 Dorton Lane', 'Buffalo', 'NY', '14276', 'rwaslinglj@edublogs.org'),
(72, 'Jody', 'Cardenas', '22 Valley Edge Trail', 'Buffalo', 'NY', '14220', 'jcardenaslk@cam.ac.uk'),
(73, 'Euphemia', 'Aicken', '90069 Merrick Park', 'Buffalo', 'NY', '14210', 'eaickenmc@bing.com'),
(74, 'Margaret', 'Blagbrough', '958 Canary Center', 'Buffalo', 'NY', '14220', 'mblagbroughmh@linkedin.co'),
(75, 'Red', 'Growden', '0259 Meadow Valley Juncti', 'Buffalo', 'NY', '14269', 'rgrowdenms@princeton.edu'),
(76, 'Elysee', 'Knoller', '77350 Mockingbird Park', 'Buffalo', 'NY', '14269', 'eknollern8@admin.ch'),
(77, 'Glory', 'Vasyagin', '42 Nevada Avenue', 'Buffalo', 'NY', '14205', 'gvasyaginnj@ustream.tv'),
(78, 'Charlena', 'Newlan', '61459 Eliot Hill', 'Buffalo', 'NY', '14233', 'cnewlannq@cbsnews.com'),
(79, 'Wynn', 'Dovinson', '68802 Schlimgen Center', 'Buffalo', 'NY', '14210', 'wdovinsonns@slashdot.org'),
(80, 'Jeramie', 'Pole', '38004 Doe Crossing Terrac', 'Buffalo', 'NY', '14220', 'jpoleny@rediff.com'),
(81, 'Levy', 'Coveney', '80 Spenser Hill', 'Buffalo', 'NY', '14210', 'lcoveneyo4@fema.gov'),
(82, 'Livvy', 'Hebron', '560 Kensington Hill', 'Buffalo', 'NY', '14210', 'lhebronp2@chronoengine.co'),
(83, 'Drud', 'Whitely', '41 Columbus Court', 'Buffalo', 'NY', '14233', 'dwhitelyp7@un.org'),
(84, 'Isiahi', 'Hembry', '6379 Roxbury Parkway', 'Buffalo', 'NY', '14225', 'ihembrypx@mozilla.com'),
(85, 'Craggie', 'McGenn', '2856 Continental Point', 'Buffalo', 'NY', '14269', 'cmcgennqe@wiley.com'),
(86, 'Hyacinthia', 'Pariss', '85 Hintze Street', 'Buffalo', 'NY', '14269', 'hparissql@kickstarter.com'),
(87, 'Gladys', 'Safell', '46 Corben Alley', 'Buffalo', 'NY', '14210', 'gsafellqn@businessinsider'),
(88, 'Brian', 'Holyard', '67 Vernon Trail', 'Buffalo', 'NY', '14233', 'bholyardr4@wisc.edu'),
(89, 'Bourke', 'Smees', '3053 Crowley Alley', 'Buffalo', 'NY', '14205', 'bsmeesrb@shop-pro.jp'),
(90, 'Errick', 'Winser', '7 Springview Lane', 'Buffalo', 'NY', '14233', 'ewinserro@php.net'),
(92, 'Al', 'Katerinsky', '221B Baker St', 'Buffalo', 'NY', '14226', 'aak29@buffalo.edu'),
(93, 'Willy', 'Walrus', '99 Delaware Park', 'Buffalo', 'NY', '14216', 'wwalrus@buffalo.edu'),
(94, 'John', 'Watson', '221B Baker St', 'Buffalo', 'NY', '14213', 'jwatson@holmes.org'),
(95, 'Bilbo', 'Baggins', '125 Bagshot Row', 'Hobbiton', 'The Shire', '1ring', 'frodo@baggins.edu'),
(96, 'Elvis', 'Pressly', 'Lonely Street', 'Buffalo', 'NY', '14203', 'hhotel@buffalo.edu'),
(99, 'Wally', 'Walrus', '99 Delaware Park', 'Buffalo', 'NY', '14216', 'wwalrus@buffalo.edu'),
(100, 'Andy', 'Panda', '99 Delaware Park', 'Buffalo', 'NY', '14216', 'apanda@buffalo.edu'),
(101, 'Amanda', 'Panda', '221B Baker St', 'Buffalo', 'NY', '12156', 'apanda@buffalo.edu'),
(103, 'Zippy', 'Pinhead', '1100 Delaware Ave', 'Buffalo', 'NY', '14204', 'zpinhead@rcross.org'),
(104, 'Andy', 'Montrois', '221B Baker St', 'Buffalo', 'NY', '14216', 'ajmontro@buffalo.edu'),
(105, 'Willy', 'Walrus', '99 Delaware Park', 'Buffalo', 'NY', '14216', 'wwalrus@buffalo.edu');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ProductID` int(3) NOT NULL,
  `ProductName` varchar(25) NOT NULL,
  `ProductDesciption` varchar(100) NOT NULL,
  `Price` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ProductID`, `ProductName`, `ProductDesciption`, `Price`) VALUES
(3, 'Beer - Blue Light', 'malesuada in imperdiet et commodo vulputate justo in blandit ultrices enim lorem ipsum', '$26.16'),
(4, 'Wine - Shiraz Wolf Blass ', 'vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae', '$24.73'),
(5, 'Cake - Box Window 10x10x2', 'tempus semper est quam pharetra magna ac consequat metus sapien ut nunc vestibulum ante ipsum primis', '$28.83'),
(6, 'Nestea - Ice Tea, Diet', 'pede libero quis orci nullam molestie nibh in lectus pellentesque', '$14.84'),
(7, 'Bread - Italian Sesame Po', 'arcu sed augue aliquam erat volutpat in congue etiam justo etiam pretium', '$10.93'),
(8, 'Peas Snow', 'sem sed sagittis nam congue risus semper porta volutpat quam pede lobortis ligula sit amet eleifend ', '$26.84'),
(9, 'Bread - Italian Corn Meal', 'potenti in eleifend quam a odio in hac habitasse platea dictumst maecenas ut massa quis augue luctus', '$47.99'),
(10, 'Tarragon - Fresh', 'orci vehicula condimentum curabitur in libero ut massa volutpat convallis morbi odio odio elementum ', '$27.58'),
(11, 'Cheese - Cheddar With Cla', 'vitae nisl aenean lectus pellentesque eget nunc donec quis orci eget orci vehicula condimentum curab', '$40.62'),
(12, 'Lemonade - Mandarin, 591 ', 'accumsan felis ut at dolor quis odio consequat varius integer ac leo pellentesque ultrices', '$21.09'),
(13, 'Dooleys Toffee', 'fermentum justo nec condimentum neque sapien placerat ante nulla justo aliquam quis', '$28.30'),
(14, 'Table Cloth - 53x69 Colou', 'aliquam convallis nunc proin at turpis a pede posuere nonummy integer non', '$44.99'),
(15, 'Icecream - Dibs', 'laoreet ut rhoncus aliquet pulvinar sed nisl nunc rhoncus dui vel sem sed sagittis nam congue risus', '$6.07'),
(16, 'Cheese Cheddar Processed', 'ipsum dolor sit amet consectetuer adipiscing elit proin interdum mauris non ligula', '$10.72'),
(17, 'Wine - Stoneliegh Sauvign', 'potenti nullam porttitor lacus at turpis donec posuere metus vitae ipsum aliquam non mauris', '$46.23'),
(18, 'Ecolab - Medallion', 'eget tempus vel pede morbi porttitor lorem id ligula suspendisse ornare consequat lectus in est', '$4.63'),
(19, 'Wine - Red, Concha Y Toro', 'eget rutrum at lorem integer tincidunt ante vel ipsum praesent blandit lacinia erat vestibulum sed m', '$13.94'),
(20, 'Chutney Sauce', 'porttitor lacus at turpis donec posuere metus vitae ipsum aliquam', '$19.46'),
(21, 'Cinnamon Buns Sticky', 'leo maecenas pulvinar lobortis est phasellus sit amet erat nulla tempus vivamus in felis eu sapien c', '$30.57'),
(22, 'Ham - Procutinni', 'ornare consequat lectus in est risus auctor sed tristique in tempus sit', '$12.67'),
(23, 'Ham - Cooked Bayonne Tinn', 'nulla sed accumsan felis ut at dolor quis odio consequat varius integer ac leo pellentesque ultrices', '$3.45'),
(24, 'Raisin - Dark', 'justo lacinia eget tincidunt eget tempus vel pede morbi porttitor lorem id ligula suspendisse ornare', '$49.29'),
(25, 'Table Cloth 72x144 White', 'interdum mauris ullamcorper purus sit amet nulla quisque arcu libero rutrum ac lobortis vel dapibus ', '$18.85'),
(26, 'Juice - Orange, 341 Ml', 'tincidunt in leo maecenas pulvinar lobortis est phasellus sit amet erat', '$35.15'),
(27, 'Onions - Cooking', 'porta volutpat erat quisque erat eros viverra eget congue eget semper rutrum nulla nunc purus phasel', '$15.88'),
(28, 'Catfish - Fillets', 'lorem quisque ut erat curabitur gravida nisi at nibh in hac habitasse platea dictumst', '$31.48'),
(29, 'Raspberries - Fresh', 'nibh in hac habitasse platea dictumst aliquam augue quam sollicitudin vitae', '$17.89'),
(30, 'Bread - Focaccia Quarter', 'quam fringilla rhoncus mauris enim leo rhoncus sed vestibulum sit amet cursus id turpis', '$44.53'),
(31, 'Milk - Chocolate 250 Ml', 'in hac habitasse platea dictumst maecenas ut massa quis augue luctus tincidunt nulla mollis molestie', '$48.20'),
(32, 'Water - Evian 355 Ml', 'proin leo odio porttitor id consequat in consequat ut nulla sed accumsan felis', '$31.78'),
(33, 'Veal - Inside', 'morbi a ipsum integer a nibh in quis justo maecenas rhoncus aliquam lacus morbi', '$37.11'),
(34, 'Wine - Red, Lurton Merlot', 'nisl duis ac nibh fusce lacus purus aliquet at feugiat non pretium quis lectus suspendisse potenti i', '$9.47'),
(35, 'Crab - Back Fin Meat, Can', 'diam erat fermentum justo nec condimentum neque sapien placerat ante nulla justo aliquam', '$48.11'),
(36, 'Nut - Hazelnut, Whole', 'nascetur ridiculus mus etiam vel augue vestibulum rutrum rutrum neque aenean auctor gravida sem prae', '$29.49'),
(37, 'Cheese - Goat', 'bibendum imperdiet nullam orci pede venenatis non sodales sed tincidunt eu felis fusce', '$32.59'),
(38, 'Tea - Apple Green Tea', 'non mattis pulvinar nulla pede ullamcorper augue a suscipit nulla elit ac nulla sed vel enim sit ame', '$31.61'),
(39, 'Tomato - Plum With Basil', 'ipsum aliquam non mauris morbi non lectus aliquam sit amet diam in', '$47.81'),
(40, 'Oranges - Navel, 72', 'euismod scelerisque quam turpis adipiscing lorem vitae mattis nibh ligula', '$11.64'),
(41, 'Soup - Cream Of Potato / ', 'massa id lobortis convallis tortor risus dapibus augue vel accumsan tellus nisi eu orci mauris lacin', '$6.85'),
(42, 'Wine - Ej Gallo Sierra Va', 'ac est lacinia nisi venenatis tristique fusce congue diam id ornare imperdiet sapien urna', '$27.59'),
(43, 'Wine - Tio Pepe Sherry Fi', 'nulla elit ac nulla sed vel enim sit amet nunc', '$49.38'),
(44, 'Oil - Margarine', 'orci vehicula condimentum curabitur in libero ut massa volutpat convallis morbi odio odio elementum ', '$7.97'),
(45, 'Turkey - Ground. Lean', 'proin eu mi nulla ac enim in tempor turpis nec euismod', '$43.90');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pid` int(11) NOT NULL,
  `product` varchar(20) NOT NULL,
  `price` decimal(6,2) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pid`, `product`, `price`, `description`) VALUES
(1, 'Bread - Rosemary Foc', '0.46', 'amet eleifend pede libero quis orci nullam molestie nibh in lectus pellentesque at'),
(2, 'Zucchini - Mini, Gre', '7.40', 'sem fusce consequat nulla nisl nunc nisl duis bibendum felis sed interdum venenatis turpis enim blandit'),
(3, 'Lotus Leaves', '0.03', 'phasellus id sapien in sapien iaculis congue vivamus metus arcu adipiscing molestie hendrerit at vulputate'),
(4, 'Chocolate - Compound', '2.80', 'luctus et ultrices posuere cubilia curae mauris viverra diam vitae quam suspendisse potenti nullam porttitor lacus at turpis'),
(5, 'Country Roll', '5.65', 'potenti in eleifend quam a odio in hac habitasse platea dictumst maecenas ut'),
(6, 'Lidsoupcont Rp12dn', '7.05', 'pulvinar lobortis est phasellus sit amet erat nulla tempus vivamus in felis eu sapien cursus vestibulum'),
(7, 'Bread Crumbs - Japan', '8.98', 'adipiscing elit proin interdum mauris non ligula pellentesque ultrices phasellus'),
(8, 'Island Oasis - Lemon', '4.84', 'turpis integer aliquet massa id lobortis convallis tortor risus dapibus augue vel accumsan tellus nisi eu'),
(9, 'Fish - Atlantic Salm', '2.89', 'integer ac neque duis bibendum morbi non quam nec dui'),
(10, 'Herb Du Provence - P', '4.22', 'faucibus orci luctus et ultrices posuere cubilia curae nulla dapibus dolor vel est donec odio justo sollicitudin ut suscipit'),
(11, 'Wine - Crozes Hermit', '4.08', 'diam in magna bibendum imperdiet nullam orci pede venenatis non sodales sed tincidunt'),
(12, 'Pasta - Penne, Lisce', '6.62', 'imperdiet et commodo vulputate justo in blandit ultrices enim lorem'),
(13, 'Veal - Shank, Pieces', '0.58', 'ultricies eu nibh quisque id justo sit amet sapien dignissim vestibulum vestibulum ante ipsum'),
(14, 'Pepper - Cubanelle', '7.98', 'pretium iaculis diam erat fermentum justo nec condimentum neque sapien placerat ante nulla justo aliquam quis'),
(15, 'Chicken - Base, Ulti', '2.40', 'adipiscing molestie hendrerit at vulputate vitae nisl aenean lectus pellentesque eget nunc donec quis orci eget'),
(16, 'Nut - Hazelnut, Grou', '5.54', 'turpis elementum ligula vehicula consequat morbi a ipsum integer a nibh in quis justo maecenas rhoncus'),
(17, 'Cookie - Oatmeal', '2.83', 'vestibulum quam sapien varius ut blandit non interdum in ante vestibulum ante ipsum'),
(18, 'Veal - Inside', '4.97', 'vitae ipsum aliquam non mauris morbi non lectus aliquam sit amet'),
(19, 'Cake Slab', '5.17', 'erat quisque erat eros viverra eget congue eget semper rutrum nulla nunc purus phasellus in felis donec semper sapien'),
(20, 'Lettuce - Arugula', '4.14', 'non mi integer ac neque duis bibendum morbi non quam nec'),
(21, 'Rice - Long Grain', '1.65', 'ut odio cras mi pede malesuada in imperdiet et commodo vulputate'),
(22, 'Yeast Dry - Fleischm', '9.31', 'justo eu massa donec dapibus duis at velit eu est congue elementum in hac habitasse platea'),
(23, 'Bread - Olive', '5.43', 'dui nec nisi volutpat eleifend donec ut dolor morbi vel lectus in quam'),
(24, 'Milk 2% 500 Ml', '2.41', 'rhoncus dui vel sem sed sagittis nam congue risus semper porta volutpat quam pede lobortis ligula sit amet eleifend pede'),
(25, 'Onions Granulated', '4.42', 'tempus sit amet sem fusce consequat nulla nisl nunc nisl'),
(26, 'Flavouring Vanilla A', '5.81', 'ipsum ac tellus semper interdum mauris ullamcorper purus sit amet nulla quisque'),
(27, 'Pomegranates', '2.07', 'morbi vestibulum velit id pretium iaculis diam erat fermentum justo nec condimentum neque sapien placerat ante nulla justo aliquam'),
(28, 'Thyme - Dried', '7.37', 'porttitor lacus at turpis donec posuere metus vitae ipsum aliquam non mauris morbi non'),
(29, 'Snapple Lemon Tea', '4.08', 'accumsan odio curabitur convallis duis consequat dui nec nisi volutpat eleifend'),
(30, 'Cheese - Brie,danish', '8.44', 'ut suscipit a feugiat et eros vestibulum ac est lacinia nisi venenatis tristique fusce congue diam id ornare imperdiet'),
(31, 'Corn Shoots', '0.37', 'nullam molestie nibh in lectus pellentesque at nulla suspendisse potenti cras in purus'),
(32, 'Wine - Magnotta - Be', '3.00', 'orci pede venenatis non sodales sed tincidunt eu felis fusce posuere felis sed lacus morbi sem mauris laoreet'),
(33, 'Cheese - Colby', '0.58', 'vulputate nonummy maecenas tincidunt lacus at velit vivamus vel nulla eget eros elementum pellentesque quisque porta volutpat erat quisque erat'),
(34, 'Shark - Loin', '4.21', 'lacinia sapien quis libero nullam sit amet turpis elementum ligula vehicula consequat morbi a ipsum'),
(35, 'Pastry - Apple Muffi', '2.17', 'adipiscing molestie hendrerit at vulputate vitae nisl aenean lectus pellentesque eget nunc donec quis orci eget orci vehicula condimentum'),
(36, 'Bread Base - Toscano', '6.17', 'libero non mattis pulvinar nulla pede ullamcorper augue a suscipit nulla elit ac nulla sed vel'),
(37, 'Sorrel - Fresh', '7.75', 'dapibus nulla suscipit ligula in lacus curabitur at ipsum ac tellus semper interdum mauris ullamcorper purus sit'),
(38, 'Soup Campbells Beef ', '0.69', 'et eros vestibulum ac est lacinia nisi venenatis tristique fusce congue diam id ornare imperdiet sapien'),
(39, 'Tomato - Plum With B', '3.47', 'ultrices posuere cubilia curae nulla dapibus dolor vel est donec odio justo sollicitudin ut suscipit a feugiat'),
(40, 'Trueblue - Blueberry', '9.98', 'molestie nibh in lectus pellentesque at nulla suspendisse potenti cras in purus eu'),
(41, 'Jolt Cola - Electric', '3.51', 'enim blandit mi in porttitor pede justo eu massa donec dapibus duis at velit eu est congue'),
(42, 'Beef - Bones, Marrow', '9.08', 'ac diam cras pellentesque volutpat dui maecenas tristique est et tempus semper est quam pharetra'),
(43, 'Beef - Sushi Flat Ir', '8.57', 'turpis nec euismod scelerisque quam turpis adipiscing lorem vitae mattis nibh ligula nec sem duis aliquam convallis nunc proin'),
(44, 'Chicken - Bones', '3.15', 'sapien sapien non mi integer ac neque duis bibendum morbi non quam nec dui luctus rutrum nulla tellus'),
(45, 'Swiss Chard - Red', '9.99', 'condimentum curabitur in libero ut massa volutpat convallis morbi odio odio elementum'),
(46, 'Appetizer - Lobster ', '7.77', 'ultrices vel augue vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae donec pharetra'),
(47, 'Dried Cherries', '3.56', 'et ultrices posuere cubilia curae donec pharetra magna vestibulum aliquet ultrices erat tortor sollicitudin mi sit'),
(48, 'Beef - Rib Roast, Ca', '2.32', 'at velit eu est congue elementum in hac habitasse platea dictumst morbi vestibulum velit id pretium iaculis'),
(49, 'Wine - White Cab Sau', '8.23', 'fusce posuere felis sed lacus morbi sem mauris laoreet ut rhoncus aliquet pulvinar sed nisl nunc rhoncus dui vel sem'),
(50, 'Container - Clear 32', '0.74', 'cras pellentesque volutpat dui maecenas tristique est et tempus semper est quam pharetra magna ac'),
(51, 'Lamb Tenderloin Nz F', '2.36', 'quis odio consequat varius integer ac leo pellentesque ultrices mattis odio donec vitae nisi nam ultrices'),
(52, 'Wine - Placido Pinot', '5.47', 'odio in hac habitasse platea dictumst maecenas ut massa quis augue luctus tincidunt nulla'),
(53, 'Shrimp, Dried, Small', '3.19', 'luctus tincidunt nulla mollis molestie lorem quisque ut erat curabitur gravida nisi at nibh in'),
(54, 'Crab Brie In Phyllo', '3.86', 'aliquet at feugiat non pretium quis lectus suspendisse potenti in eleifend quam a odio'),
(55, 'Chocolate - Compound', '0.40', 'viverra dapibus nulla suscipit ligula in lacus curabitur at ipsum ac tellus semper interdum mauris ullamcorper purus'),
(56, 'Bread - Sour Sticks ', '2.29', 'libero rutrum ac lobortis vel dapibus at diam nam tristique'),
(57, 'Soup - Campbells, Cr', '9.94', 'sit amet lobortis sapien sapien non mi integer ac neque duis'),
(58, 'Slt - Individual Por', '7.95', 'porttitor pede justo eu massa donec dapibus duis at velit eu est congue elementum in hac habitasse platea dictumst morbi'),
(59, 'Pastry - Chocolate M', '8.35', 'molestie hendrerit at vulputate vitae nisl aenean lectus pellentesque eget nunc donec quis orci eget'),
(60, 'Pickerel - Fillets', '0.95', 'orci nullam molestie nibh in lectus pellentesque at nulla suspendisse'),
(61, 'Syrup - Monin - Pass', '7.15', 'purus eu magna vulputate luctus cum sociis natoque penatibus et magnis dis parturient montes nascetur ridiculus mus vivamus'),
(62, 'Spoon - Soup, Plasti', '9.62', 'nulla suscipit ligula in lacus curabitur at ipsum ac tellus semper interdum mauris ullamcorper purus'),
(63, 'Pasta - Canelloni, S', '8.94', 'massa id lobortis convallis tortor risus dapibus augue vel accumsan tellus nisi eu orci mauris lacinia'),
(64, 'Island Oasis - Sweet', '8.55', 'sit amet nulla quisque arcu libero rutrum ac lobortis vel dapibus at diam nam tristique tortor eu'),
(65, 'Crush - Orange, 355m', '6.15', 'sed accumsan felis ut at dolor quis odio consequat varius integer ac leo pellentesque ultrices mattis odio donec vitae nisi'),
(66, 'Beer - Muskoka Cream', '4.33', 'neque duis bibendum morbi non quam nec dui luctus rutrum nulla tellus in sagittis dui vel'),
(67, 'Glass - Juice Clear ', '2.89', 'nullam porttitor lacus at turpis donec posuere metus vitae ipsum aliquam non mauris morbi non'),
(68, 'Wine - White, Riesli', '6.15', 'nulla quisque arcu libero rutrum ac lobortis vel dapibus at diam nam tristique tortor'),
(69, 'Apron', '6.67', 'nulla facilisi cras non velit nec nisi vulputate nonummy maecenas tincidunt'),
(70, 'Dates', '8.59', 'venenatis tristique fusce congue diam id ornare imperdiet sapien urna pretium nisl ut volutpat sapien arcu sed augue aliquam'),
(71, 'Lemon Grass', '5.61', 'in purus eu magna vulputate luctus cum sociis natoque penatibus et magnis dis'),
(72, 'Bread - Italian Corn', '8.80', 'condimentum curabitur in libero ut massa volutpat convallis morbi odio odio elementum'),
(73, 'Orange Roughy 4/6 Oz', '0.69', 'laoreet ut rhoncus aliquet pulvinar sed nisl nunc rhoncus dui vel sem'),
(74, 'Chickensplit Half', '1.24', 'aliquam erat volutpat in congue etiam justo etiam pretium iaculis justo in hac habitasse platea dictumst etiam faucibus cursus urna'),
(75, 'Irish Cream - Butter', '5.25', 'cursus id turpis integer aliquet massa id lobortis convallis tortor risus dapibus augue vel accumsan tellus nisi'),
(76, 'Cotton Wet Mop 16 Oz', '8.76', 'augue vestibulum rutrum rutrum neque aenean auctor gravida sem praesent id massa id nisl'),
(77, 'Pork - Tenderloin, F', '0.62', 'libero non mattis pulvinar nulla pede ullamcorper augue a suscipit nulla elit ac nulla sed vel enim'),
(78, 'Quail - Jumbo', '8.87', 'eget elit sodales scelerisque mauris sit amet eros suspendisse accumsan tortor quis'),
(79, 'Tarts Assorted', '9.47', 'non mauris morbi non lectus aliquam sit amet diam in magna bibendum imperdiet'),
(80, 'Dawn Professionl Pot', '4.74', 'vulputate luctus cum sociis natoque penatibus et magnis dis parturient montes nascetur ridiculus mus'),
(81, 'Island Oasis - Sweet', '10.00', 'consequat morbi a ipsum integer a nibh in quis justo maecenas rhoncus'),
(82, 'Bread - Bistro Sour', '7.65', 'leo maecenas pulvinar lobortis est phasellus sit amet erat nulla tempus vivamus in felis eu sapien cursus'),
(83, 'Onions - Red', '2.64', 'leo pellentesque ultrices mattis odio donec vitae nisi nam ultrices libero non mattis pulvinar nulla pede ullamcorper'),
(84, 'Syrup - Monin - Blue', '4.80', 'eget eleifend luctus ultricies eu nibh quisque id justo sit amet sapien'),
(85, 'Pastry - Apple Large', '7.74', 'aliquam convallis nunc proin at turpis a pede posuere nonummy integer non velit donec'),
(86, 'Spice - Montreal Ste', '4.59', 'sapien a libero nam dui proin leo odio porttitor id consequat in consequat ut nulla sed accumsan felis ut'),
(87, 'Wooden Mop Handle', '2.81', 'orci luctus et ultrices posuere cubilia curae donec pharetra magna vestibulum aliquet'),
(88, 'Lettuce - Arugula', '3.67', 'praesent id massa id nisl venenatis lacinia aenean sit amet justo morbi'),
(89, 'Gingerale - Diet - S', '9.59', 'leo rhoncus sed vestibulum sit amet cursus id turpis integer aliquet massa'),
(90, 'Capon - Whole', '4.23', 'nullam porttitor lacus at turpis donec posuere metus vitae ipsum aliquam non mauris morbi non lectus aliquam sit amet diam'),
(91, 'Chicken - Breast, 5 ', '3.44', 'in hac habitasse platea dictumst aliquam augue quam sollicitudin vitae'),
(92, 'Wine - Pinot Noir La', '2.05', 'varius ut blandit non interdum in ante vestibulum ante ipsum primis in faucibus'),
(93, 'Sprouts - Bean', '3.41', 'nisl duis bibendum felis sed interdum venenatis turpis enim blandit mi in porttitor pede justo'),
(94, 'Pail - 4l White, Wit', '6.65', 'mauris sit amet eros suspendisse accumsan tortor quis turpis sed ante vivamus tortor duis mattis egestas metus'),
(95, 'Swiss Chard', '5.02', 'in faucibus orci luctus et ultrices posuere cubilia curae mauris viverra diam vitae'),
(96, 'Beef Cheek Fresh', '4.25', 'vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae nulla dapibus dolor vel est donec'),
(97, 'Wood Chips - Regular', '7.65', 'venenatis turpis enim blandit mi in porttitor pede justo eu massa donec dapibus'),
(98, 'Vol Au Vents', '4.64', 'nulla mollis molestie lorem quisque ut erat curabitur gravida nisi at nibh in hac habitasse platea dictumst'),
(99, 'Wanton Wrap', '9.99', 'lacus curabitur at ipsum ac tellus semper interdum mauris ullamcorper purus sit'),
(100, 'Bread Bowl Plain', '2.28', 'sem fusce consequat nulla nisl nunc nisl duis bibendum felis sed interdum venenatis turpis');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CustID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ProductID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `CustID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
