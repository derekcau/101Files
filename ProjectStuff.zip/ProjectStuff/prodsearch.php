<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Search results</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="style.css"/>
	<!--TEAM Stooges- Moe Howard, Larry Fine, Jerome Howard, Shemp Howard -->
</head>
<body>
<a href="index.html">Return to Switchboard</a>

<table border=1 cellpadding=2 cellspacing=1>

<tr>
<th>ID</th>
<th>Product </th>
<th>Price</th>
<th>Description </th>
</tr>
<?php
// make connection to MySQL
$con = mysqli_connect("localhost", "root", "root") or die("Error connecting to database: ".mysqli_error());
    
     
    mysqli_select_db($con, "project") or die(mysqli_error());
    // gets value sent over search form
    $query = $_POST['query'];  
    
	// changes characters used in html to their equivalents, for example: < to &gt;
	$query = htmlspecialchars($query);
           
	// makes sure nobody uses SQL injection */
    $query = mysqli_real_escape_string($con, $query);
		
     	
	//check to see that that a search term was entered
	if (!$query)
 {
	 echo "<h2>You did not enter anything to search for</h2>.</br>";
	 echo "<a href=prodsearcher.html>"."Please enter a search term"."</a>";
	 exit;
 }    
        $sql =("SELECT * FROM products
            WHERE (`product` LIKE '%".$query."%') OR (`description` LIKE '%".$query."%')");
			// or die(mysqli_error());
			// execute the SELECT Query
$records = mysqli_query($con, $sql);

//Fetch the records

while ($row = mysqli_fetch_array($records))

{
	echo "<tr>";
	echo "<td>".$row['pid']."</td>";
	echo "<td>".$row['product']."</td>";
	echo "<td>"."$".$row['price']."</td>";
	echo "<td>".$row['description']."</td>";
}
    if(mysqli_query($con, $sql))
		echo "<p>" . mysqli_affected_rows($con) . " row(s) found"."</p>";
	
	else
		echo "No records found.";
    
	?>
</body>
</html>