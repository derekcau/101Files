<?php
// TEAM Stooges- Moe Howard, Larry Fine, Jerome Howard, Shemp Howard
//Make connection variable
$con = mysqli_connect('127.0.0.1', 'root','root');
//check the connection
if (!$con)
{
	echo 'Not connected';
}

if (!mysqli_select_db($con, 'project'))
{
	echo 'Database Not Selected';
}

//set variable from the POST array
$first = $_POST['FirstName'];
$last = $_POST['LastName'];
$address = $_POST['Address1'];
$city = $_POST['City'];
$state = $_POST['State'];
$zip= $_POST['zip'];
$email = $_POST['email'];
 // check to see that the entry has at least name and email
 if (!$last || !$email)
 {
	 echo "<h1>Please complete your entry</h1>.</br>";
	 echo "<a href=adcust.html>"."<h2>Back to previous page</h2>"."</a>"."</br>";
	 echo "<a href=index.html>"."<h3>OR Return to Switchboard</h3>"."</a>";
	 exit;
 }
// set a variable for the sql insert statement
$sql = "INSERT INTO customer(FirstName,LastName,Address1,City,State,zip,email) VALUES ('$first','$last','$address','$city','$state','$zip','$email')";

//check the database for insertion

if (!mysqli_query($con, $sql))
{
	echo 'Not Inserted';
}
else{
	echo "Welcome!" . "<p>". mysqli_affected_rows($con) . " record(s) added.</p>"; 
}

header("refresh:5; url=index.html");
?>